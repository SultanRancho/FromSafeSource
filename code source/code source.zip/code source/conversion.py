

def convertir_web(liste):
    str_web = str()

    # convertis la liste en str
    if liste:
        for a in liste:
            str_web = str_web + " " + a

    # supprime les espaces inutiles
    str_web = str_web.strip()

    # remplace les caractères spéciaux
    str_web = str_web.replace(" ", "+").replace("'", "%27")

    return str_web


def convertir_str(liste):
    str_normal = str()

    if liste:
        for a in liste:
            str_normal = str_normal + " " + a

    str_normal = str_normal.strip()

    return str_normal
