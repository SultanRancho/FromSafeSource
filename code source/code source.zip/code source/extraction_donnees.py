import os
import sys
import hashlib


def get_data(nom_bdd):
    application_path = "C:/"
    liste_keywords = []
    liste_actions = []
    liste_position_arguments = []

    if getattr(sys, 'frozen', False):
        application_path = os.path.dirname(sys.executable)
    elif __file__:
        application_path = os.path.dirname(__file__)

    config_path = os.path.join(application_path, nom_bdd)

    data = open(config_path, "r", encoding="utf8")
    line = data.read().splitlines()
    data.close()

    data = open(config_path, "rb")
    line2 = data.read()
    data.close()

    md5 = hashlib.md5(line2).hexdigest()

    # vérifie la validité du fichier user.data
    if md5 == "1c796294d15d8f2667a2530d27751c79":
        for i in line:
            if not line[0] == "#":
                keywords = i[0:i.rfind("|", 0, i.rfind("|"))].split()
                liste_keywords.insert(len(liste_keywords), keywords)

                action = i[i.rfind("|", 0, i.rfind("|"))+1:i.rfind("|")]
                liste_actions.insert(len(liste_actions), action.strip())

                position_argument_temp = i[i.rfind("|")+1:len(i)].split()
                position_argument = []
                for f in position_argument_temp:
                    try:
                        position_argument.insert(len(position_argument), int(f))
                    except:
                        position_argument.insert(len(position_argument), f)

                liste_position_arguments.insert(len(liste_position_arguments), position_argument)
    else:
        liste_keywords = "ERROR"

    return liste_keywords, liste_position_arguments,  liste_actions
