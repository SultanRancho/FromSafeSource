

def naissance(contenue):
    start_keyword = [" est né ", " né ", " est née ", " née ", " venu au monde "]
    end_keyword = [".", ",", " mais ", " et ", " donc ", " or ", " ni ", " car ", " parce que ", " dans ",
                   " au ", " lors ", " à "]

    content = contenue

    if content:
        save_pos = len(content)
        save_pos2 = len(content)
        # longueur du texte de début de réponse
        len_b1 = 0

        # cherche le début de la réponse
        for a in start_keyword:
            pos = content.lower().find(a)
            if -1 < pos < save_pos:
                save_pos = pos
                len_b1 = len(a)

        # cherche la fin de la réponse
        for b in end_keyword:
            pos = content.lower().find(b, save_pos + len_b1)
            if -1 < pos < save_pos2:
                save_pos2 = pos

        result = content[save_pos + len_b1:save_pos2].strip()
    else:
        result = False

    return result


def mort(contenue):
    start_keyword = [" est mort ", " mort ", " est décédé ", " décédé ", " est morte ", " morte ", " est décédée ", " décédée "]
    end_keyword = [".", ",", " mais ", " et ", " donc ", " or ", " ni ", " car ", " parce que ", " dans ",
                   " au ", " lors ", " à "]

    content = contenue

    if content:
        save_pos = len(content)
        save_pos2 = len(content)
        # longueur du texte de début de réponse
        len_b1 = 0

        # cherche le début de la réponse
        for a in start_keyword:
            pos = content.lower().find(a)
            if -1 < pos < save_pos:
                save_pos = pos
                len_b1 = len(a)

        # cherche la fin de la réponse
        for b in end_keyword:
            pos = content.lower().find(b, save_pos + len_b1)
            if -1 < pos < save_pos2:
                save_pos2 = pos

        result = content[save_pos + len_b1:save_pos2].strip()
    else:
        result = False

    return result


def definition(contenue):
    start_keyword = [" est ", " est un ", " est une ", " est la ", " est le "]
    end_keyword = ["."]

    content = contenue

    if content:
        save_pos = len(content)
        save_pos2 = len(content)
        # longueur du texte de début de réponse
        len_b1 = 0

        # cherche le début de la réponse
        for a in start_keyword:
            pos = content.lower().find(a)
            if -1 < pos < save_pos:
                save_pos = pos
                len_b1 = len(a)

        # cherche la fin de la réponse
        for b in end_keyword:
            pos = content.lower().find(b, save_pos + len_b1)
            if -1 < pos < save_pos2:
                save_pos2 = pos

        result = content[save_pos + len_b1:save_pos2].strip()
    else:
        result = False

    return result


def capitale(contenue):
    start_keyword = [" est la capitale ", " la capitale ", " capitale "]
    end_keyword = [".", ",", " mais ", " et ", " donc ", " or ", " ni ", " car ", " parce que ", " dans ",
                   " au ", " lors ", " à "]

    content = contenue

    if content:
        save_pos = len(content)
        save_pos2 = len(content)
        # longueur du texte de début de réponse
        len_b1 = 0

        # cherche le début de la réponse
        for a in start_keyword:
            pos = content.lower().find(a)
            if -1 < pos < save_pos:
                save_pos = pos
                len_b1 = len(a)

        # cherche la fin de la réponse
        for b in end_keyword:
            pos = content.lower().find(b, save_pos + len_b1)
            if -1 < pos < save_pos2:
                save_pos2 = pos

        result = content[save_pos + len_b1:save_pos2].strip()
    else:
        result = False

    return result


def localiser(contenue):
    start_keyword = [" la capitale de ", " la capitale et plus grande ville", " la capitale ", " capitale ",
                     " un village ", " se trouve ", " une commune ", " se situe ",
                     " une cité-état ",  " une cité état ", " une ville ", " ville d'"]
    end_keyword = [".", ",", " mais ", " donc ", " or ", " ni ", " car ", " parce que ",
                   " au ", " lors ", " et "]
    exception_longueur = [" une ville ", " un village ", " une commune ", " une cité-état ",  " une cité état "]

    content = contenue

    if content:
        save_pos = len(content)
        save_pos2 = len(content)
        # longueur du texte de début de réponse
        len_b1 = 0

        # cherche le début de la réponse
        for a in start_keyword:
            pos = content.lower().find(a)
            if -1 < pos < save_pos:
                save_pos = pos
                # vérifie si il doit récupérer à partir du début ou de la fin du repère
                try:
                    exception_longueur.index(a)
                    len_b1 = 0
                except:
                    len_b1 = len(a)

        # cherche la fin de la réponse
        for b in end_keyword:
            pos = content.lower().find(b, save_pos + len_b1)
            if -1 < pos < save_pos2:
                save_pos2 = pos

        result = content[save_pos + len_b1:save_pos2].strip()
    else:
        result = False

    return result


def creation(contenue):
    start_keyword = ["fondée en", "fondé en", "créée en", "crée en"]
    end_keyword = [".", ",", " mais ", " et ", " donc ", " or ", " ni ", " car ", " parce que ", " dans ",
                   " au ", " lors ", " à "]
    exception_longueur = []

    content = contenue

    if content:
        save_pos = len(content)
        save_pos2 = len(content)
        # longueur du texte de début de réponse
        len_b1 = 0

        # cherche le début de la réponse
        for a in start_keyword:
            pos = content.lower().find(a)
            if -1 < pos < save_pos:
                save_pos = pos
                # vérifie si il doit récupérer à partir du début ou de la fin du repère
                try:
                    exception_longueur.index(a)
                    len_b1 = 0
                except:
                    len_b1 = len(a)

        # cherche la fin de la réponse
        for b in end_keyword:
            pos = content.lower().find(b, save_pos)
            if -1 < pos < save_pos2:
                save_pos2 = pos

        result = content[save_pos + len_b1:save_pos2].strip()
    else:
        result = False

    return result


def realisateur(liste):
    print(liste)
    return_content = str()
    try:
        start = liste.index("De")
        stop = liste.index("Par")

        realisateurs = liste[start+1:stop]

        if len(realisateurs) > 2:
            return_content = realisateurs[0]
            for a in range(len(realisateurs)-2):
                return_content = return_content + ", " + realisateurs[a+1]
            return_content = return_content + " et " + realisateurs[len(realisateurs)-1]
        elif len(realisateurs) == 2:
            return_content = realisateurs[0] + " et " + realisateurs[1]
        else:
            return_content = realisateurs[0]
        return_content = return_content.strip()
    except ValueError:
        return_content = False

    return return_content
