import comprehension
import choix_commande
import source
import struct_source
import conversion
import adaptation
import lien
import list_source


def get_reponse(texte):
    return_content = ["OK", ""]

    if texte:
        # interprete la phrase surligné
        interpretation = comprehension.interpretation(texte.lower().split(), "user.data")

        source_var = list_source.get_source(interpretation[0])

        # contient la liste des sources. mettre ici le lien de la page de recherche et remplacer l'emplacement du mot-clé par <['keyword']>
        liste_de_lien = source_var[0]
        liste_param = source_var[1]

        if interpretation[0] != 'nope' and interpretation[1] and liste_de_lien and liste_param and not interpretation[1] == "ERROR":
            # convertis le mot-clé pour le web et en string
            word_web = conversion.convertir_web(interpretation[1][0])
            word = conversion.convertir_str(interpretation[1][0])

            for a in range(len(liste_de_lien)):
                # met le mot-clé à l'emplacement voulu
                url = liste_de_lien[a]
                url_page = url.replace("<['keyword']>", word_web)

                page = lien.openapi(url_page, liste_param[a][0], exclut=liste_param[a][1],
                                    prefixe=liste_param[a][2], suffixe=liste_param[a][3])[0]

                # va chercher la bonne information dans la page
                type_phrase = interpretation[0]
                content_filtred = ""
                if liste_param[a][4] == "simple":
                    content_filtred = source.get_text(page)
                elif liste_param[a][4] == "structured":
                    content_filtred = struct_source.get_text(page)

                print(content_filtred)

                reponse = choix_commande.extract(interpretation[0], content_filtred[0])

                if reponse:
                    if type_phrase.find("_remplace") > -1:
                        return_content = ["OK", reponse, content_filtred[1]]
                    else:
                        return_content = ["OK", adaptation.adapte(reponse, texte, interpretation[0]), content_filtred[1]]
                    break
                else:
                    return_content = ["ERROR", "Echec"]
        elif interpretation[1] == "ERROR":
            return_content = ["ERROR", "user.data a été corrompu. Retélécharger le fichier ou télecharger la nouvelle version"]
        else:
            return_content = ["ERROR", "Echec"]
    else:
        return_content = ["ERROR", "Texte vide"]

    return return_content