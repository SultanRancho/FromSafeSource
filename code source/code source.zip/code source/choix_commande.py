import commande
# exécute les bonnes commandes en fonctions du type renvoyé par l'interpréteur


def extract(type: str, contenue: str):
    return_content = False

    if type == "naissance" or type == "naissance_remplace":
        data = commande.naissance(contenue)
        return_content = data

    if type == "mort" or type == "mort_remplace":
        data = commande.mort(contenue)
        return_content = data

    if type == "definition" or type == "definition_remplace":
        data = commande.definition(contenue)
        return_content = data

    if type == "capitale" or type == "capitale_remplace":
        data = commande.capitale(contenue)
        return_content = data

    if type == "localisation" or type == "localisation_remplace":
        data = commande.localiser(contenue)
        return_content = data

    if type == "creation" or type == "creation_remplace":
        data = commande.creation(contenue)
        return_content = data

    if type == "realisation" or type == "realisation_remplace":
        data = commande.realisateur(contenue)
        return_content = data

    return return_content
