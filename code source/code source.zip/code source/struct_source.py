import requests
import metadata


def get_text(url):
    try:
        liste_texte = list()
        # récupère le contenue d'une page html
        content = requests.get(url, headers={"User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) "
                                                           "AppleWebKit/537.36 (KHTML, like Gecko) "
                                                           "Chrome/96.0.4664.110 "
                                                           "Mobile Safari/537.36"}).content.decode()

        title = metadata.get_titre(content)

        tags = ["p", "h1", "h2", "h3", "h4", "h5", "h6", "a", "span"]

        text = str()
        start_reading = False
        style_or_js = False
        b2 = int()
        actual_tag = str()

        # extrait le text contenue dans les balises utiles
        for a in range(len(content)):
            if content[a] == "<" and not start_reading:
                b1 = a
                b2 = content.find(">", a)+1

                # cherche le nom de la balise ex: a, h1, h2
                insidetag = content[b1:b2]

                # vérifie si la balise doit être lu
                for b in tags:
                    if insidetag == "<" + b + ">" or insidetag[0:len(b)+2] == "<" + b + " ":
                        start_reading = True
                        actual_tag = b

            if start_reading:
                if content[a:a+len("</"+actual_tag+">")] == "</"+actual_tag+">" and not style_or_js:
                    start_reading = False
                    liste_texte.insert(len(liste_texte), text)
                    text = ""
                elif a > b2-1:
                    text = text + content[a]

        final_text = str()
        lt2 = list()

        # supprime le texte entre < et > pour supprimer les restes de html.
        if liste_texte:
            reading = True
            for d in liste_texte:
                for c in d:
                    if c == "<":
                        reading = False
                    elif c == ">":
                        reading = True

                    if reading and not c == ">" and not style_or_js:
                        final_text = final_text + c
                lt2.insert(len(lt2), final_text.replace("\n", ""))
                final_text = ""
    except requests.ConnectionError:
        lt2 = False
        title = False

    return [lt2, title]
