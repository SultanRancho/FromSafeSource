from win10toast import ToastNotifier
import time
import keyboard
import win32clipboard
import recherche
import os
import sys
import external

# determine l'emplacement de l'éxecutable ou du script
application_path = "C:/"

if getattr(sys, 'frozen', False):
    application_path = os.path.dirname(sys.executable)
elif __file__:
    application_path = os.path.dirname(__file__)

icone = os.path.join(application_path, "icone.ico")

running = False

# notification de démarrage
verification = external.verify()
toast = ToastNotifier()
if not verification:
    toast.show_toast("FromSafeSource", "FromSafeSource est activé.", duration=3, icon_path=icone)
    running = True
elif verification[0] == "ERROR":
    toast = ToastNotifier()
    toast.show_toast("FromSafeSource", verification[1], duration=3, icon_path=icone)
    if verification[1] == "Vous n'êtes pas connecté à internet":
        running = False
        toast.show_toast("FromSafeSource", "FromSafeSource est désactivé.", duration=3, icon_path=icone)

hotkey_call = 'ctrl+alt+shift+p'
hotkey_end = 'ctrl+alt+shift+d'
reponse = ["OK", "Hello world"]

while running:
    try:
        # vérifie si le raccourci d'éxecution est pressé
        keyboard.wait("ctrl")
        start = keyboard.is_pressed(hotkey_call)
        stop = keyboard.is_pressed(hotkey_end)
        control = keyboard.is_pressed("ctrl")
        index = 0
        while control and not start and not stop:
            start = keyboard.is_pressed(hotkey_call)
            stop = keyboard.is_pressed(hotkey_end)
            control = keyboard.is_pressed("ctrl")
            if start:
                # simule un relachement des touches du raccourci
                keyboard.release(hotkey=hotkey_call)

                # simule un ctrl+c pour copier
                keyboard.press(hotkey="ctrl")
                keyboard.press(hotkey="c")
                keyboard.release(hotkey="ctrl")
                keyboard.release(hotkey="c")
                time.sleep(0.05)

                try:
                    # lis dans le presse papier
                    win32clipboard.OpenClipboard()
                    data = win32clipboard.GetClipboardData()
                    win32clipboard.CloseClipboard()
                    data2 = str()

                    # supprime les caractères problématiques
                    for a in data:
                        if a.encode() != b'\x00':
                            data2 = data2 + a
                    data = data2
                    # recherche la phrase de réponse
                    reponse = recherche.get_reponse(data)

                    # si la réponse est trouvé remplacer le texte, sinon afficher l'erreur renvoyée par notification
                    if reponse[0] == "OK":
                        keyboard.write(reponse[1])
                        toast.show_toast("FromSafeSource", "Source : "+reponse[2],
                                         duration=5, icon_path=icone)
                    elif reponse[0] == "ERROR":
                        toast.show_toast("FromSafeSource", reponse[1],
                                         duration=5,
                                         icon_path=icone)
                except:
                    # renvoie une erreur par notification lorsque le presse-papier refuse l'accès
                    toast.show_toast("FromSafeSource", "Une erreur est survenue en relation avec le presse papier. Veuillez réesayer ou relancer FromSafeSource",
                                     duration=5, icon_path=icone)

            # vérifie si le raccourci d'arrêt est pressé
            if stop:
                running = False
                toast.show_toast("FromSafeSource", "FromSafeSource est désactivé.", duration=3, icon_path=icone)

            index += 1
    except KeyboardInterrupt:
        running = False
