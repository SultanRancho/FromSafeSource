import requests
# verification des mises à jour et de la connexion


def verify():
    return_content = []
    try:
        version = b'0.1\n'
        last_version = requests.get("https://raw.githubusercontent.com/SultanRancho/FromSafeSource/main/version.mdt")
        if last_version.status_code == 200:
            if last_version.content != version:
                return_content = ["ERROR", "Une nouvelle version est disponible"]
    except requests.ConnectionError:
        return_content = ["ERROR", "Vous n'êtes pas connecté à internet"]

    return return_content
