
# extrait le titre de la source
def get_titre(contenue):
    return_content = False

    # recherche les balises title
    b1 = contenue.find("<title>")
    b2 = contenue.find("</title>")

    if b1 > -1:
        titre = contenue[b1+7:b2]
        return_content = titre

    return return_content
