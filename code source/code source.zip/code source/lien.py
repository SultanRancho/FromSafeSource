import requests


def openapi(url: str, liens: list,
            exclut: list = ...,
            prefixe: str = ...,
            suffixe: str = ...):
    return_content = ["ERROR", "Impossible de rechercher les informations"]

    try:
        # récupére le contenue html de la page
        requete = requests.get(url, headers={"User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) "
                                                           "AppleWebKit/537.36 (KHTML, like Gecko) "
                                                           "Chrome/96.0.4664.110 "
                                                           "Mobile Safari/537.36"})

        # vérifie si la requête s'est correctement déroulée
        if requete.status_code == 200:
            return_link_list = list()

            # body de la réponse
            contenue = requete.content.decode()

            index1 = 0

            # recherche tous les liens commencant par les chaines spécifiés dans liens
            for a in liens:

                delete = False

                if a.find("<[delete]>") > -1:
                    delete = True
                    a = a.replace("<[delete]>", "")

                # s'éxecute tant qu'il trouve une nouvelle occurence
                while index1 != -1:
                    # position de la première lettre
                    if delete:
                        index1 = contenue.find(a, index1)
                        if index1 != -1:
                            index1 = index1 + len(a)
                    else:
                        index1 = contenue.find(a, index1)

                    if index1 != -1:
                        end_url_character = ['"', "'", "<", "\\"]

                        index2 = len(contenue)
                        modifier = False

                        # position de la dernière lettre
                        for b in end_url_character:
                            pos = contenue.find(b, index1)
                            if pos != -1 and pos < index2:
                                index2 = pos
                                modifier = True

                        # ajoute le lien si il trouve son début et sa fin
                        if modifier:
                            lien = contenue[index1:index2]
                            add = True

                            # vérifie si il doit être inclut
                            if not exclut == Ellipsis:
                                for b in exclut:
                                    if lien.find(b) > -1:
                                        add = False

                            # ajoute le préfixe si il est spécifié
                            if not prefixe == Ellipsis:
                                lien = prefixe + lien

                            # ajoute le suffixe si il est spécifié
                            if not suffixe == Ellipsis:
                                lien = lien + suffixe

                            # ajoute le lien
                            if add:
                                return_link_list.insert(len(return_content), lien)
                        index1 += 1
                return_content = return_link_list[contenue.count('sponsored":true'):len(return_content)]
        else:
            return_content = ["ERROR", "Page non trouvé"]
    except requests.ConnectionError:
        # erreur de connexion
        return_content = ["ERROR", "Impossible de se connecter au site demandé"]

    return return_content
