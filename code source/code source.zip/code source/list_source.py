

def get_source(type_format):

    liste_source = ["https://fr.wikipedia.org/w/index.php?search=<['keyword']>&title=Sp%C3%A9cial%3ARecherche&profile=advanced&fulltext=1&ns0=1",
                    "https://www.allocine.fr/_/autocomplete/<['keyword']>"]

    liste_param = [[["/wiki/"], ["Spécial:", "Special:", "Wikipédia:", "Wikip%C3%A9dia:", "Sp%C3%A9cial:", "Aide:"], "https://fr.wikipedia.org", "", "simple"],
                   [['entity_id":"<[delete]>'], [], "https://www.allocine.fr/film/fichefilm_gen_cfilm=", ".html", "structured"]]

    associated_type = [["naissance", "naissance_remplace", "mort", "mort_remplace", "definition", "definition_remplace",
                        "capitale", "capitale_remplace", "localisation", "localisation_remplace", "creation", "creation_remplace"], ["realisation"]]

    return_source = list()
    return_param = list()

    # sélectionne les paramètres adaptés
    for a in range(len(associated_type)):
        for b in associated_type[a]:
            if b == type_format:
                return_source.insert(len(return_source), liste_source[a])
                return_param.insert(len(return_param), liste_param[a])

    return [return_source, return_param]
