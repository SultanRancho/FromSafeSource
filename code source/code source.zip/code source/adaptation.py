

def adapte(reponse: str, texte: str, type_format: str):
    remplace = texte
    reponse = reponse.replace("'", "' ")

    # trouve le dernier mots du texte envoyer par l'utilisateur
    dernier_mot = texte.split()[len(texte.split())-1]
    premier_mot = reponse.split()[0]

    determinant_connus = ["le", "la", "les", "un", "une", "du", "de", "d'"]
    autres_connus = ["en", "à", "au", "dans"]

    mots_connus = determinant_connus + autres_connus

    type_mot = False
    type_mot2 = False

    # applique des règles spéciales pour la localisation

    # vérifie si le dernier mot du texte utilisateur est un déterminant
    for a in mots_connus:
        if dernier_mot == a:
            try:
                determinant_connus.index(a)
                type_mot = "determinant"
            except ValueError:
                try:
                    autres_connus.index(a)
                    type_mot = "autres"
                except ValueError:
                    type_mot = False

    for a in mots_connus:
        if premier_mot == a:
            try:
                determinant_connus.index(a)
                type_mot2 = "determinant"
            except ValueError:
                try:
                    autres_connus.index(a)
                    type_mot2 = "autres"
                except ValueError:
                    type_mot2 = False

    remplace_shut = remplace[0:remplace.find(dernier_mot)].strip()
    reponse_shut = reponse[reponse.find(premier_mot)+len(premier_mot):len(reponse)].strip()

    if type_format == "naissance":
        if type_mot == "determinant" and type_mot2 == "determinant":
            remplace = remplace_shut
        elif type_mot == "autres" and type_mot2 == "determinant":
            remplace = remplace_shut
    elif type_format == "mort":
        if type_mot == "determinant" and type_mot2 == "determinant":
            remplace = remplace_shut
        elif type_mot == "autres" and type_mot2 == "determinant":
            remplace = remplace_shut
    elif type_format == "capitale":
        if dernier_mot == "de" and premier_mot == "de":
            remplace = remplace_shut
    elif type_format == "localisation":
        if (dernier_mot == "en" and premier_mot == "en") \
                or (dernier_mot == "au" and premier_mot == "au") \
                or (dernier_mot == "dans" and premier_mot == "dans"):
            remplace = remplace_shut
        elif premier_mot == "un" or premier_mot == "une":
            if remplace.find(" se trouve") > -1:
                remplace = remplace[0:remplace.find(" se trouve")].strip() + " est"
            elif remplace.find(" se situe") > -1:
                remplace = remplace[0:remplace.find(" se situe")].strip() + " est"
            elif remplace.find(" est localisé") > -1:
                remplace = remplace[0:remplace.find(" se situe")].strip() + " est"
            elif remplace.find(" est localiser") > -1:
                remplace = remplace[0:remplace.find(" se situe")].strip() + " est"
        elif premier_mot == "la" or premier_mot == "de" or premier_mot == "d'":
            if dernier_mot == "en":
                reponse = reponse_shut
            else:
                reponse = "en " + reponse_shut
        elif premier_mot == "le" or premier_mot == "du":
            if dernier_mot == "au":
                reponse = reponse_shut
            else:
                reponse = "au " + reponse_shut
    elif type_format == "creation":
        if dernier_mot == "en" and premier_mot == "en":
            remplace = remplace_shut
    elif type_format == "realisation":
        remplace = remplace
    # si le dernier mot du texte utilisateur est un déterminant alors le dernier mot est supprimer.
    # sinon les chaines sont concaténés avec un espace.
    remplace = remplace.strip() + " " + reponse.strip()

    remplace = remplace.strip()

    return remplace
