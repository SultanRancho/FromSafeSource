import extraction_donnees as speak


def interpretation(texte, nom_bdd):
    save_count_word = 0
    index = 0
    index_save = -1

    texte_var = list(texte)
    type_return = "nope"

    # Recupère les modèles en base de donnée
    data_extract = speak.get_data(nom_bdd)
    liste_de_phrase = data_extract[0]
    if not liste_de_phrase == "ERROR":
        # Verifie si la phrase correspond à un des modèles présent en base de données
        for a in liste_de_phrase:
            reserve = list(texte)
            count_word = 0
            # Cherche les mots
            for b in a:
                if reserve.count(b) > 0:
                    reserve.pop(reserve.index(b))
                    count_word += 1

            reserve = a

            if count_word > save_count_word and count_word == len(a):
                # Verifie si les mots sont dans l'ordre
                for c in texte_var:
                    if c == reserve[0]:
                        reserve.pop(0)
                    if len(reserve) == 0:
                        break

                if len(reserve) == 0:
                    index_save = index
                    save_count_word = count_word

            index += 1

        index2 = 0
        index3 = 0
        type = ""
        argument = []
        argument_globale = []

        # Recupère les modèles en base de donnée
        data_extract = speak.get_data(nom_bdd)
        liste_de_phrase = data_extract[0]
        position_argument_phrase = data_extract[1]
        type_phrase = data_extract[2]

        # Recherche les arguments
        for d in texte_var:
            for e in position_argument_phrase[index_save]:
                if e == index3 or (e == "end" and len(liste_de_phrase[index_save]) == index2):
                    try:
                        if not d == liste_de_phrase[index_save][index2]:
                            argument.insert(len(argument), d)
                    except:
                        argument.insert(len(argument), d)

            if len(liste_de_phrase[index_save]) != index2 and d == liste_de_phrase[index_save][index2]:
                index2 += 1
                index3 += 1
                type = "keyword"
                if argument:
                    argument_globale.insert(len(argument), argument)
                    argument = []
            else:
                if type == "keyword":
                    type = "random texte"

        if argument:
            argument_globale.insert(len(argument), argument)

        if index_save != -1:
            type_return = type_phrase[index_save]
    else:
        argument_globale = "ERROR"

    return type_return, argument_globale
